package com.example.springrest.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Data;


@NoArgsConstructor
@Data
@Entity
@Table(name="TeacherInfo")
public class Teacher {

	@Id
	@Column(name="teacher_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tid;
	private String tname;
	private String department;
	private double salary;
	
}

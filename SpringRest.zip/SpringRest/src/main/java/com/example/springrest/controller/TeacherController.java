package com.example.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springrest.entity.Teacher;
import com.example.springrest.service.ITeacherService;

@RestController
@RequestMapping("/api/teacher")
public class TeacherController {

	@Autowired
	ITeacherService service;
	
	//@RequestMapping(value="/add",method= RequestMethod.POST)
	@PostMapping("/add")
	public Teacher add(@RequestBody Teacher teacher) {
		return service.addTeacher(teacher);
	}
		
	@PutMapping("/update/{id}")
	public Teacher update(@RequestBody Teacher teacher, @PathVariable int id)
	{
		Teacher teachernew = service.selectTeacherById(id);
		service.selectTeacherById(id);
		teachernew.setTname(teacher.getTname());
		teachernew.setDepartment(teacher.getDepartment());
		teachernew.setSalary(teacher.getSalary());
		return service.updateTeacher(teachernew);
	}
		
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
		service.deleteTeacherById(id);
		return "Recored Deleted Successfully";
	}
		
	@GetMapping("/get/{id}")
	public Teacher  getById(@PathVariable  int id) {
		return service.selectTeacherById(id);
	}
		
	@GetMapping("/getall")
	public List<Teacher>  getAll()
	{
		return service.selectAllTeacher();
	}
	
}
